import React,{Component} from 'react'

export default class Login extends Component {
    render(){
        return <div>
            您访问的页面不存在
        </div>
    }
}