import React,{Component} from 'react'

export default class Chat extends Component {
    render(){
        return <div>
            聊天...
        </div>
    }
}