import React,{Component} from 'react'

export default class Mine extends Component {
    render(){
        return <div>
            mine...
        </div>
    }
}