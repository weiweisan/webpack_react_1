import React, { Component } from 'react'
import axios from 'axios'
import { Item } from 'semantic-ui-react'
import Tloader from 'react-touch-loader'
import './Loader.css'

export default class Loader extends Component {
  constructor(props) {
    super()

    this.state = {
      initializing: 1,
      hasMore: true, //是否还有数据
      type: props.type,
      pagenum: 0, //开始的条数
      pagesize: 2, //每页多少条
      list: []
    }
  }

  // 当父组件给子组件传递的props发生了改变
  componentWillReceiveProps(nextProps) {
    this.state.type = nextProps.type

    // 重置，然后根据type去加载该type的第一页数据
    this.setState(
      {
        pagenum: 0,
        pagesize: 2,
        hasMore: true,
        list: []
      },
      () => {
        this.loadData()
      }
    )
  }

  componentWillMount() {
    this.loadData()
  }

  loadData = async resolve => {
    const result = await axios.post('infos/list', {
      type: this.state.type,
      pagenum: this.state.pagenum,
      pagesize: this.state.pagesize
    })

    if (result.data.meta.status === 200) {
      const newArray = this.state.list.concat(result.data.data.list.data)
      this.setState(
        {
          list: newArray,
          hasMore: newArray.length < result.data.data.list.total
        },
        () => {
          resolve && resolve()
        }
      )
    }
  }

  renderListView = () => {
    const { type, list } = this.state
    if (type === 1 || type === 2) {
      return (
        <Item.Group unstackable>
          {list.map(item => {
            return (
              <Item key={item.id}>
                <Item.Image src="http://47.96.21.88:8086/public/1.png" />
                <Item.Content>
                  <Item.Header className="info-title">
                    {item.info_title}
                  </Item.Header>
                  <Item.Meta>$1200 1 Month</Item.Meta>
                </Item.Content>
              </Item>
            )
          })}
        </Item.Group>
      )
    } else {
      return <div>问答</div>
    }
  }

  // 把之前的内容都重置，然后加载第一页的数据
  handleRefresh = resolve => {
    this.state.pagenum = 0
    this.state.pagesize = 2
    this.setState(
      {
        list: [],
        hasMore: true
      },
      () => {
        this.loadData(resolve)
      }
    )
  }

  // 加载更多
  handleLoadMore = resolve => {
    this.state.pagenum = this.state.pagenum + this.state.pagesize

    this.loadData(resolve)
  }

  render() {
    const { initializing, hasMore } = this.state
    return (
      <div>
        <Tloader
          initializing={initializing}
          onRefresh={this.handleRefresh}
          hasMore={hasMore}
          onLoadMore={this.handleLoadMore}
          className="main"
        >
          {this.renderListView()}
        </Tloader>
      </div>
    )
  }
}
